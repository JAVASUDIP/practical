package hellojavaop;

public class ArithmeticOp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 10; //variable declear
		int b = 20;  //variable seclear.
		
		System.out.println("a+b= is " + (a+b));
		System.out.println("a-b= is"  + (a-b));
		System.out.println("a*b= is " +(a*b));
		System.out.println("a/b = is "+(a/b));
		System.out.println("a%b = is "+(a%b));
		
		
		
	}

}
