package com.qspiders.abstraction;


   interface AmazonCompany
   {
	   void listofbook();
	   void order();
	   void delevery();
   }

 class  Onlineshoping implements AmazonCompany
 {
	 public void listofbook()
	 {
		 System.out.println("Welcome to Amazon compny");
		 System.out.println("ckeck the book");
		 System.out.println("find my book and order place");
	 }
	 public void order()
	 
	 {
		System.out.println("please add the book item");
		System.out.println("make the payment");
		System.out.println("order sucefuly");
		
	}
	 
	 public void delivery()
	 {
		 System.out.println("track the delery from Amazon company");
	 }
	@Override
	public void delevery() {
		// TODO Auto-generated method stub
		
	}
	 
 }

 class Flipkart implements AmazonCompany
 {
	 public void listofbook()
	 {
		 System.out.println("Welcome to Flipkrt compny");
		 System.out.println("make the payment");
	     System.out.println("order sucefuly");
	 }
	 public void delivery()
	 {
		 System.out.println("track the delery from Flipkart company");
	 }
	@Override
	public void order() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void delevery() {
		// TODO Auto-generated method stub
		
	}
 }
 
    class AmazonApp
    {
      AmazonCompany selectOnlineshoping(char choice)
      {
    	  if (choice == 'e')
      
      {
       return new Onlineshoping();
      }
    	  else 
    	  {
    		  return new Flipkart();
    	  }
    
      }
    }

public class Program12 
   {
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		AmazonApp ap = new AmazonApp();
		AmazonCompany ac = ap.selectOnlineshoping('e');
		
		ac.listofbook();
		ac.order();
		ac.delevery();
	}
   }
